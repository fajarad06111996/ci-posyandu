<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/highcharts.js"></script>

<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD </h2>
            </div>

           
            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-pink ">
                        <div class="icon">
                           <i class="fa fa-users"></i>

                        </div>
                        <div class="content">
                            <div class="text">DATA BALITA</div>
                              <a href="<?php echo base_url("admin/");?>" class="small-box-footer"><font color="white">Lihat <i class="fa fa-arrow-circle-right"></i></a></font>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan ">
                        <div class="icon">
                           <i class="fa fa-file"></i>

                        </div>
                        <div class="content">
                            <div class="text">DATA PERKEMBANGAN</div>
                            <a href="<?php echo base_url("admin/");?>" class="small-box-footer"><font color="white">Lihat  <i class="fa fa-arrow-circle-right"></i></a></font> 

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-light-green ">
                        <div class="icon">
                            <i class="fa fa-file"></i>
                        </div>
                        <div class="content">
                            <div class="text">DATA USER</div>
                             <a href="<?php echo base_url("admin/");?>" class="small-box-footer"><font color="white">Lihat  <i class="fa fa-arrow-circle-right"></i></a></font> 

                    </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-orange ">
                        <div class="icon">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="content">
                            <div class="text">DATA ADMIN</div>
                           <a href="<?php echo base_url("admin/");?>"class="small-box-footer"><font color="white">Lihat <i class="fa fa-arrow-circle-right"></i></a></font> 
                      
                    </div>
                    </div>
                </div>
            </div>
            <!-- #END# Widgets -->
            
            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2> </h2>
                        </div>
                        <div class="body">
                      <center><h3>SISTEM INFORMASI E POSYANDUS </h3></center> 
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
            </div>
            
                    <div class="col-lg-14 mb-4">
                              <div class="card h-100"> <br/>
                                <!-- <h4 class="card-header"><center>PERKEMBANGAN BALITA</center></h4> -->
                                <div class="card-body">
                                <body>
                                

                                <!-- <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div> -->


                                        <script type="text/javascript">

                                // Create the chart
                                // Highcharts.chart('container', {
                                    // chart: {
                                        // type: 'column'
                                    // },
                                    // title: {
                                        // text: ''
                                    // },
                                    // subtitle: {
                                        // text: 'DATA POSYANDUS'
                                    // },
                                    // xAxis: {
                                        // type: 'category'
                                    // },
                                    // yAxis: {
                                        // title: {
                                            // text: 'Jumlah Penduduk'
                                        // }

                                    // },
                                    // legend: {
                                        // enabled: false
                                    // },
                                    // plotOptions: {
                                        // series: {
                                            // borderWidth: 0,
                                            // dataLabels: {
                                                // enabled: true,
                                                // format: '{point.y:1f}'
                                            // }
                                        // }
                                    // },

                                    // tooltip: {
                                        // headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                                        // pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.f}</b> Penduduk<br/>'
                                    // },

                                    // series: [{
                                        // name: 'DATA',
                                        // colorByPoint: true,
                                        // data: [{
                                            // name: 'Data Penduduk',
                                            // y: 1,
                                            // drilldown: null
                                        // },{
                                            // name: 'Data Kematian',
                                            // y: 1,
                                            // drilldown: null
                                        // }, {
                                            // name: 'Data Kepindahan',
                                            // y: 2,
                                            // drilldown: null
                                        // }, {
                                            // name: 'Data Kelahiran',
                                            // y: 3,
                                            // drilldown: null
                                        // }
                                        // ]
                                    // }],
                                // });
                                        </script>
                                    </body>
                                </div>
                                <div class="card-footer">
                                  
                                </div>
                              </div>
                            </div>


    </section>