<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/highcharts.js"></script>

<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD </h2>
            </div>

           
            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-pink ">
                        <div class="icon">
                           <i class="fa fa-users"></i>

                        </div>
                        <div class="content">
                            <div class="text">DATA BALITA</div>
                              <a href="<?php echo base_url("balita/data_balita");?>" class="small-box-footer"><font color="white">Lihat <i class="fa fa-arrow-circle-right"></i></a></font>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan ">
                        <div class="icon">
                           <i class="fa fa-file"></i>

                        </div>
                        <div class="content">
                            <div class="text">DATA IMUNISASI</div>
                            <a href="<?php echo base_url("balita/data_imunisasi");?>" class="small-box-footer"><font color="white">Lihat  <i class="fa fa-arrow-circle-right"></i></a></font> 

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-light-green ">
                        <div class="icon">
                            <i class="fa fa-file"></i>
                        </div>
                        <div class="content">
                            <div class="text">DATA GIZI</div>
                             <a href="<?php echo base_url("balita/data_gizi");?>" class="small-box-footer"><font color="white">Lihat  <i class="fa fa-arrow-circle-right"></i></a></font> 

                    </div>
                    </div>
                </div>
                <!-- <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-orange ">
                        <div class="icon">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="content">
                            <div class="text">DATA USER</div>
                           <a href="<?php //echo base_url("balita/");?>"class="small-box-footer"><font color="white">Lihat <i class="fa fa-arrow-circle-right"></i></a></font> 
                      
                    </div>
                    </div>
                </div> -->
            </div>
            <!-- #END# Widgets -->
            
            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2> </h2>
                        </div>
                        <div class="body">
                      <center><h3>SISTEM INFORMASI E POSYANDUS </h3></center> 
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
            </div>
            

    </section>